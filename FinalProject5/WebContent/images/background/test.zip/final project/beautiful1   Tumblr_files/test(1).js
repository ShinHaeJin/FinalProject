/*! Copyright 2014 Cedexis Inc. */
(function(){if(cedexis&&cedexis.radar){cedexis.radar.stopped_at=new Date()}}());
